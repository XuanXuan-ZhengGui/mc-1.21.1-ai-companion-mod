package com.xuanxuan.aicompanion.client.mixin;

import com.xuanxuan.aicompanion.client.gui.AiBotConnectScreen;
import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_442;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_442.class)
public abstract class TitleScreenMixin extends class_437 {
    protected TitleScreenMixin(class_2561 title) {
        super(title);
    }

    @Inject(method = "init", at = @At("TAIL"))
    private void aiCompanion$addAiBotButton(CallbackInfo ci) {
        int centerX = field_22789 / 2;
        int y = field_22790 - 40;
        method_37063(class_4185.method_46430(class_2561.method_43470("AI Bot 客户端"), button ->
                field_22787.method_1507(new AiBotConnectScreen(this))
        ).method_46434(centerX - 100, y, 200, 20).method_46431());
    }
}
