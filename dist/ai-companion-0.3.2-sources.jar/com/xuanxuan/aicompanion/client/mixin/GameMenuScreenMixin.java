package com.xuanxuan.aicompanion.client.mixin;

import com.xuanxuan.aicompanion.client.gui.AiProviderScreen;
import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_433;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_433.class)
public abstract class GameMenuScreenMixin extends class_437 {
    protected GameMenuScreenMixin(class_2561 title) {
        super(title);
    }

    @Inject(method = "init", at = @At("TAIL"))
    private void aiCompanion$addProviderButton(CallbackInfo ci) {
        int buttonWidth = 204;
        int buttonHeight = 20;
        int x = field_22789 / 2 - buttonWidth / 2;
        int y = field_22790 / 4 + 144;

        method_37063(class_4185.method_46430(class_2561.method_43471("button.ai_companion.join_ai"), button ->
                field_22787.method_1507(new AiProviderScreen(this))
        ).method_46434(x, y, buttonWidth, buttonHeight).method_46431());
    }
}
