package com.xuanxuan.aicompanion.client.gui;

import net.minecraft.class_1923;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

public final class LoadedMapScreen extends class_437 {
    private static final int RADIUS = 16;
    private static final int CELL_SIZE = 6;
    private static final int GAP = 1;

    public LoadedMapScreen() {
        super(class_2561.method_43471("screen.ai_companion.map"));
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        context.method_27534(field_22793, field_22785, field_22789 / 2, 18, 0xFFFFFF);

        if (field_22787 == null || field_22787.field_1724 == null || field_22787.field_1687 == null) {
            context.method_27534(field_22793, class_2561.method_43470("请先进入一个世界。"), field_22789 / 2, field_22790 / 2, 0xFF5555);
            return;
        }

        class_1923 center = field_22787.field_1724.method_31476();
        int mapSize = (RADIUS * 2 + 1) * (CELL_SIZE + GAP);
        int startX = (field_22789 - mapSize) / 2;
        int startY = 44;

        for (int dz = -RADIUS; dz <= RADIUS; dz++) {
            for (int dx = -RADIUS; dx <= RADIUS; dx++) {
                int chunkX = center.field_9181 + dx;
                int chunkZ = center.field_9180 + dz;
                boolean loaded = field_22787.field_1687.method_2935().method_12123(chunkX, chunkZ);
                int color = loaded ? 0xFF4CAF50 : 0xFF000000;

                if (dx == 0 && dz == 0) {
                    color = 0xFFFFD54F;
                }

                int x = startX + (dx + RADIUS) * (CELL_SIZE + GAP);
                int y = startY + (dz + RADIUS) * (CELL_SIZE + GAP);
                context.method_25294(x, y, x + CELL_SIZE, y + CELL_SIZE, color);
            }
        }

        int legendY = startY + mapSize + 12;
        context.method_27535(field_22793, class_2561.method_43470("黄色：玩家所在区块"), startX, legendY, 0xFFFFD54F);
        context.method_27535(field_22793, class_2561.method_43470("绿色：已加载区块"), startX, legendY + 12, 0xA5D6A7);
        context.method_27535(field_22793, class_2561.method_43470("黑色：未加载区块"), startX, legendY + 24, 0xFFFFFF);
        context.method_27534(field_22793, class_2561.method_43470("按 ESC 返回游戏"), field_22789 / 2, field_22790 - 24, 0xAAAAAA);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
