package com.xuanxuan.aicompanion.client.gui;

import com.xuanxuan.aicompanion.client.AiCompanionClient;
import com.xuanxuan.aicompanion.client.config.AiCompanionConfig;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_412;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_639;
import net.minecraft.class_642;

public final class AiBotConnectScreen extends class_437 {
    private final class_437 parent;
    private class_342 ipInput;
    private class_342 modelInput;

    public AiBotConnectScreen(class_437 parent) {
        super(class_2561.method_43470("AI Bot 客户端"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int centerX = field_22789 / 2;
        int startY = field_22790 / 2 - 56;

        ipInput = new class_342(field_22793, centerX - 120, startY + 20, 240, 20, class_2561.method_43470("IP:端口"));
        ipInput.method_1852(AiCompanionConfig.targetServerIp());
        ipInput.method_1880(256);
        method_37063(ipInput);

        modelInput = new class_342(field_22793, centerX - 120, startY + 52, 240, 20, class_2561.method_43470("模型名"));
        modelInput.method_1852(AiCompanionConfig.modelName());
        modelInput.method_1880(128);
        method_37063(modelInput);

        method_37063(class_4185.method_46430(class_2561.method_43470("连接并启动 AI"), button -> connect())
                .method_46434(centerX - 120, startY + 88, 240, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("返回"), button -> field_22787.method_1507(parent))
                .method_46434(centerX - 120, startY + 118, 240, 20).method_46431());
    }

    private void connect() {
        String address = ipInput.method_1882().trim();
        String model = modelInput.method_1882().trim();
        if (address.isBlank()) {
            AiCompanionClient.addChatMessage(class_2561.method_43470("[AI Bot] 请输入 IP:端口"));
            return;
        }
        if (model.isBlank()) {
            AiCompanionClient.addChatMessage(class_2561.method_43470("[AI Bot] 请输入模型名"));
            return;
        }

        AiCompanionConfig.setAiBotMode(true);
        AiCompanionConfig.setTargetServerIp(address);
        AiCompanionConfig.setModelName(model);
        AiCompanionConfig.save();

        try {
            class_639 serverAddress = class_639.method_2950(address);
            class_642 serverInfo = new class_642("AI Target", address, class_642.class_8678.field_45611);
            class_412.method_36877(this, field_22787, serverAddress, serverInfo, false, null);
        } catch (Exception exception) {
            AiCompanionClient.addChatMessage(class_2561.method_43470("[AI Bot] 连接失败：" + exception.getMessage()));
        }
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        int centerX = field_22789 / 2;
        int startY = field_22790 / 2 - 56;
        context.method_27534(field_22793, field_22785, centerX, startY - 16, 0xFFFFFF);
        context.method_27535(field_22793, class_2561.method_43470("目标局域网 IP:端口"), centerX - 120, startY + 6, 0xAAAAAA);
        context.method_27535(field_22793, class_2561.method_43470("模型名 (如 qwen2.5:7b)"), centerX - 120, startY + 38, 0xAAAAAA);
    }

    @Override
    public void method_25419() {
        field_22787.method_1507(parent);
    }
}
