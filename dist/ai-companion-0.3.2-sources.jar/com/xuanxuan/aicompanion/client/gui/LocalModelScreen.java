package com.xuanxuan.aicompanion.client.gui;

import com.xuanxuan.aicompanion.client.AiCompanionClient;
import com.xuanxuan.aicompanion.client.config.AiCompanionConfig;
import com.xuanxuan.aicompanion.client.entity.CompanionEntityManager;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public final class LocalModelScreen extends class_437 {
    private final class_437 parent;
    private final AiCompanionConfig.ProviderMode providerMode;
    private class_342 modelInput;

    public LocalModelScreen(class_437 parent, AiCompanionConfig.ProviderMode providerMode) {
        super(class_2561.method_43470("本地服务商"));
        this.parent = parent;
        this.providerMode = providerMode;
    }

    @Override
    protected void method_25426() {
        int centerX = field_22789 / 2;
        int startY = field_22790 / 2 - 46;

        modelInput = new class_342(field_22793, centerX - 120, startY + 42, 240, 20, class_2561.method_43470("模型名"));
        modelInput.method_1852(AiCompanionConfig.modelName());
        modelInput.method_1880(128);
        method_37063(modelInput);

        method_37063(class_4185.method_46430(class_2561.method_43471("button.ai_companion.chat"), button -> save(false))
                .method_46434(centerX - 105, startY + 78, 100, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43471("button.ai_companion.join_game"), button -> save(true))
                .method_46434(centerX + 5, startY + 78, 100, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("返回"), button -> field_22787.method_1507(parent))
                .method_46434(centerX - 50, startY + 108, 100, 20).method_46431());
    }

    private void save(boolean joinGame) {
        AiCompanionConfig.setProviderMode(providerMode);
        AiCompanionConfig.setModelName(modelInput.method_1882());
        AiCompanionConfig.setChatMode(!joinGame);
        AiCompanionConfig.setJoinedGame(joinGame);
        AiCompanionConfig.save();
        if (joinGame) {
            CompanionEntityManager.respawn(field_22787);
            AiCompanionClient.addChatMessage(class_2561.method_43470("[XuanXuan-ZhengGui] 已加入游戏。输入 @*" + AiCompanionConfig.modelName() + " 开始聊天。"));
        }
        field_22787.method_1507(null);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        int centerX = field_22789 / 2;
        int startY = field_22790 / 2 - 46;
        String provider = providerMode == AiCompanionConfig.ProviderMode.LOCAL_OLLAMA ? "本地 ollama" : "本地 llama.cpp";
        String endpoint = providerMode == AiCompanionConfig.ProviderMode.LOCAL_OLLAMA ? "127.0.0.1:11434" : "127.0.0.1:8080";
        context.method_27534(field_22793, class_2561.method_43470("服务商：" + provider), centerX, startY - 24, 0xFFFFFF);
        context.method_27534(field_22793, class_2561.method_43470("服务商 IP：" + endpoint), centerX, startY - 8, 0xAAAAAA);
        context.method_27535(field_22793, class_2561.method_43470("模型名"), centerX - 120, startY + 30, 0xAAAAAA);
        context.method_27534(field_22793, class_2561.method_43470("聊天：在游戏内输入 @*模型名 或 @模型名"), centerX, startY + 138, 0xAAAAAA);
    }

    @Override
    public void method_25419() {
        field_22787.method_1507(parent);
    }
}
