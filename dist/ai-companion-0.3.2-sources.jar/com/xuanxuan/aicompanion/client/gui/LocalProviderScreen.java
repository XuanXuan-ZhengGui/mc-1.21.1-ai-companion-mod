package com.xuanxuan.aicompanion.client.gui;

import com.xuanxuan.aicompanion.client.config.AiCompanionConfig;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public final class LocalProviderScreen extends class_437 {
    private final class_437 parent;

    public LocalProviderScreen(class_437 parent) {
        super(class_2561.method_43470("本地 AI"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int centerX = field_22789 / 2;
        int startY = field_22790 / 2 - 36;

        method_37063(class_4185.method_46430(class_2561.method_43470("ollama"), button ->
                field_22787.method_1507(new LocalModelScreen(this, AiCompanionConfig.ProviderMode.LOCAL_OLLAMA))
        ).method_46434(centerX - 105, startY, 100, 20).method_46431());

        method_37063(class_4185.method_46430(class_2561.method_43470("llama.cpp"), button ->
                field_22787.method_1507(new LocalModelScreen(this, AiCompanionConfig.ProviderMode.LOCAL_LLAMA_CPP))
        ).method_46434(centerX + 5, startY, 100, 20).method_46431());

        method_37063(class_4185.method_46430(class_2561.method_43470("返回"), button ->
                field_22787.method_1507(parent)
        ).method_46434(centerX - 50, startY + 36, 100, 20).method_46431());
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        context.method_27534(field_22793, field_22785, field_22789 / 2, field_22790 / 2 - 70, 0xFFFFFF);
        context.method_27534(field_22793, class_2561.method_43470("选择本地服务商 IP 类型"), field_22789 / 2, field_22790 / 2 - 54, 0xAAAAAA);
    }

    @Override
    public void method_25419() {
        field_22787.method_1507(parent);
    }
}
