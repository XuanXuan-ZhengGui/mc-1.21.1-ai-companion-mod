package com.xuanxuan.aicompanion.client.gui;

import com.xuanxuan.aicompanion.client.config.AiCompanionConfig;
import com.xuanxuan.aicompanion.client.entity.CompanionEntityManager;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public final class CloudConfigScreen extends class_437 {
    private final class_437 parent;
    private class_342 apiInput;
    private class_342 modelInput;

    public CloudConfigScreen(class_437 parent) {
        super(class_2561.method_43470("云端 AI"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int centerX = field_22789 / 2;
        int startY = field_22790 / 2 - 58;

        apiInput = new class_342(field_22793, centerX - 120, startY + 18, 240, 20, class_2561.method_43470("API"));
        apiInput.method_1852(AiCompanionConfig.cloudApi());
        apiInput.method_1880(512);
        method_37063(apiInput);

        modelInput = new class_342(field_22793, centerX - 120, startY + 58, 240, 20, class_2561.method_43470("模型名"));
        modelInput.method_1852(AiCompanionConfig.modelName());
        modelInput.method_1880(128);
        method_37063(modelInput);

        method_37063(class_4185.method_46430(class_2561.method_43471("button.ai_companion.chat"), button -> save(false))
                .method_46434(centerX - 105, startY + 94, 100, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43471("button.ai_companion.join_game"), button -> save(true))
                .method_46434(centerX + 5, startY + 94, 100, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("返回"), button -> field_22787.method_1507(parent))
                .method_46434(centerX - 50, startY + 124, 100, 20).method_46431());
    }

    private void save(boolean joinGame) {
        AiCompanionConfig.setProviderMode(AiCompanionConfig.ProviderMode.CLOUD);
        AiCompanionConfig.setCloudApi(apiInput.method_1882());
        AiCompanionConfig.setModelName(modelInput.method_1882());
        AiCompanionConfig.setChatMode(!joinGame);
        AiCompanionConfig.setJoinedGame(joinGame);
        AiCompanionConfig.save();
        if (joinGame) {
            CompanionEntityManager.respawn(field_22787);
        }
        field_22787.method_1507(null);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        int centerX = field_22789 / 2;
        int startY = field_22790 / 2 - 58;
        context.method_27534(field_22793, field_22785, centerX, startY - 22, 0xFFFFFF);
        context.method_27535(field_22793, class_2561.method_43471("button.ai_companion.add_api"), centerX - 120, startY + 6, 0xAAAAAA);
        context.method_27535(field_22793, class_2561.method_43470("模型名"), centerX - 120, startY + 46, 0xAAAAAA);
        context.method_27534(field_22793, class_2561.method_43470("聊天：在游戏内输入 @*模型名 或 @模型名"), centerX, startY + 154, 0xAAAAAA);
    }

    @Override
    public void method_25419() {
        field_22787.method_1507(parent);
    }
}
