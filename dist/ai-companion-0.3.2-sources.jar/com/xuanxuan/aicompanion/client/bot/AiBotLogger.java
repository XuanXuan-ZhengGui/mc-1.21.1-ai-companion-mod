package com.xuanxuan.aicompanion.client.bot;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;

public final class AiBotLogger {
    private static final DateTimeFormatter TIME_FORMAT = DateTimeFormatter.ofPattern("HH:mm:ss");
    private static boolean enabled = true;

    private AiBotLogger() {
    }

    public static void setEnabled(boolean value) {
        enabled = value;
    }

    public static boolean isEnabled() {
        return enabled;
    }

    public static void log(String category, String message) {
        if (!enabled) return;
        String time = LocalTime.now().format(TIME_FORMAT);
        class_2561 text = class_2561.method_43470("")
                .method_10852(class_2561.method_43470("[" + time + "] ").method_27692(class_124.field_1080))
                .method_10852(class_2561.method_43470("[" + category + "] ").method_27692(class_124.field_1075))
                .method_10852(class_2561.method_43470(message).method_27692(class_124.field_1068));
        send(text);
    }

    public static void think(String message) {
        log("思考", message);
    }

    public static void action(String message) {
        log("动作", message);
    }

    public static void perceive(String message) {
        log("感知", message);
    }

    public static void warn(String message) {
        log("警告", message);
    }

    public static void info(String message) {
        log("信息", message);
    }

    private static void send(class_2561 text) {
        class_310 client = class_310.method_1551();
        if (client != null && client.field_1705 != null) {
            client.field_1705.method_1743().method_1812(text);
        }
    }
}
