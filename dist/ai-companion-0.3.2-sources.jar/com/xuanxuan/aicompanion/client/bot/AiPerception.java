package com.xuanxuan.aicompanion.client.bot;

import java.util.List;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_310;
import net.minecraft.class_638;
import net.minecraft.class_746;

public final class AiPerception {
    public static final String BOT_NAME = "XuanXuan-ZhengGui";

    private AiPerception() {
    }

    public static String describe(class_310 client) {
        class_746 player = client.field_1724;
        class_638 world = client.field_1687;
        if (player == null || world == null) {
            return "无法获取环境信息。";
        }

        StringBuilder sb = new StringBuilder();
        sb.append("位置: ").append(blockPosStr(player.method_24515())).append("\n");
        sb.append("生命值: ").append(String.format("%.1f", player.method_6032())).append("/").append(player.method_6063()).append("\n");
        try {
            sb.append("饥饿值: ").append(player.method_7344().method_7586()).append("/20\n");
        } catch (Exception ignored) {
        }
        sb.append("朝向: Yaw=").append(String.format("%.0f", player.method_36454())).append(", Pitch=").append(String.format("%.0f", player.method_36455())).append("\n");
        sb.append("在地面上: ").append(player.method_24828()).append("\n");

        try {
            class_2338 frontPos = player.method_24515().method_10069(
                    (int) -Math.sin(Math.toRadians(player.method_36454())),
                    0,
                    (int) Math.cos(Math.toRadians(player.method_36454()))
            );
            String frontBlock = world.method_8320(frontPos).method_26204().toString();
            sb.append("前方方块: ").append(frontBlock).append("\n");
        } catch (Exception ignored) {
        }

        List<class_1297> nearby = world.method_8390(class_1297.class, player.method_5829().method_1014(16.0), e -> e != player);
        int hostileCount = 0;
        int playerCount = 0;
        int passiveCount = 0;
        class_1297 nearestEntity = null;
        double nearestDist = Double.MAX_VALUE;

        for (class_1297 e : nearby) {
            if (e == player) continue;
            double dist = player.method_5858(e);
            if (e instanceof class_1588) hostileCount++;
            if (e instanceof class_1657) playerCount++;
            if (e instanceof class_1296) passiveCount++;
            if (dist < nearestDist) {
                nearestDist = dist;
                nearestEntity = e;
            }
        }

        sb.append("周围实体: 敌对=").append(hostileCount).append(", 玩家=").append(playerCount).append(", 友好=").append(passiveCount).append("\n");
        if (nearestEntity != null) {
            sb.append("最近实体: ").append(nearestEntity.method_5864().method_5882())
                    .append(" 距离=").append(String.format("%.1f", Math.sqrt(nearestDist))).append("\n");
        }

        long time = world.method_8532() % 24000;
        sb.append("时间: ").append(time > 12000 ? "夜晚" : "白天").append("\n");

        return sb.toString();
    }

    private static String blockPosStr(class_2338 pos) {
        return pos.method_10263() + ", " + pos.method_10264() + ", " + pos.method_10260();
    }
}
