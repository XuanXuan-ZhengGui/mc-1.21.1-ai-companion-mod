package com.xuanxuan.aicompanion.client;

import com.xuanxuan.aicompanion.client.ai.AiRouter;
import com.xuanxuan.aicompanion.client.bot.AiBotController;
import com.xuanxuan.aicompanion.client.config.AiCompanionConfig;
import com.xuanxuan.aicompanion.client.entity.CompanionEntityManager;
import com.xuanxuan.aicompanion.client.gui.LoadedMapScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.minecraft.class_1934;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

import java.util.concurrent.CompletableFuture;

public final class AiCompanionClient implements ClientModInitializer {
    public static final String MOD_ID = "ai_companion";

    private static class_304 openMapKey;
    private static boolean lanOpened = false;
    private static int lanDelayTicks = 0;

    @Override
    public void onInitializeClient() {
        AiCompanionConfig.load();
        AiBotController.init();

        openMapKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.ai_companion.open_map",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_M,
                "category.ai_companion"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMapKey.method_1436()) {
                client.method_1507(new LoadedMapScreen());
            }
            CompanionEntityManager.tick(client);
            tryOpenLan(client);
        });

        ClientSendMessageEvents.ALLOW_CHAT.register(message -> {
            if (!shouldHandleAiMention(message)) {
                if (AiCompanionConfig.joinedGame()) {
                    CompanionEntityManager.onPlayerChat(message);
                }
                return true;
            }

            askAi(message);
            return false;
        });
    }

    private static void tryOpenLan(class_310 client) {
        if (lanOpened) return;
        if (client.method_1576() == null) return;
        if (client.field_1724 == null) return;
        if (client.field_1687 == null) return;
        if (!AiCompanionConfig.joinedGame()) return;

        lanDelayTicks++;
        if (lanDelayTicks < 40) return;

        try {
            boolean success = client.method_1576().method_3763(class_1934.field_9215, true, 0);
            if (success) {
                lanOpened = true;
                addChatMessage(class_2561.method_43470("[系统] 局域网世界已开启，其他玩家可以搜索并加入！"));
            }
        } catch (Exception exception) {
            addChatMessage(class_2561.method_43470("[系统] 开启局域网失败：" + exception.getMessage()));
        }
    }

    private static boolean shouldHandleAiMention(String message) {
        if (!AiCompanionConfig.chatMode() && !AiCompanionConfig.joinedGame()) {
            return false;
        }

        String modelName = AiCompanionConfig.modelName();
        if (modelName.isBlank()) {
            return false;
        }

        String trimmed = message.trim();
        return trimmed.startsWith("@" + modelName) || trimmed.startsWith("@*" + modelName);
    }

    private static void askAi(String message) {
        class_310 client = class_310.method_1551();
        String modelName = AiCompanionConfig.modelName();
        String prompt = message
                .replaceFirst("^@\\*?" + java.util.regex.Pattern.quote(modelName), "")
                .trim();

        addChatMessage(class_2561.method_43470("[" + modelName + "] 正在思考..."));
        CompletableFuture
                .supplyAsync(() -> AiRouter.reply(prompt.isBlank() ? message : prompt))
                .thenAccept(answer -> client.execute(() -> addChatMessage(class_2561.method_43470("[" + modelName + "] " + answer))));
    }

    public static void addChatMessage(class_2561 text) {
        class_310 client = class_310.method_1551();
        if (client.field_1705 != null) {
            client.field_1705.method_1743().method_1812(text);
        }
    }
}
