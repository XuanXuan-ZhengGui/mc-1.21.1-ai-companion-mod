package com.xuanxuan.aicompanion.client.entity;

import com.mojang.authlib.GameProfile;
import com.xuanxuan.aicompanion.client.AiCompanionClient;
import com.xuanxuan.aicompanion.client.ai.AiRouter;
import com.xuanxuan.aicompanion.client.config.AiCompanionConfig;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_745;

public final class CompanionEntityManager {
    public static final String COMPANION_NAME = "XuanXuan-ZhengGui";

    private static class_745 companion;
    private static UUID skinUuid = UUID.randomUUID();
    private static int tickCounter;
    private static int spawnDelayTicks;
    private static int deathCooldownTicks;
    private static final Random RANDOM = new Random();
    private static boolean isThinking = false;

    private CompanionEntityManager() {
    }

    public static void tick(class_310 client) {
        try {
            if (client.field_1687 == null || client.field_1724 == null || !AiCompanionConfig.joinedGame()) {
                remove(client);
                spawnDelayTicks = 0;
                deathCooldownTicks = 0;
                return;
            }

            if (deathCooldownTicks > 0) {
                deathCooldownTicks--;
                return;
            }

            if (companion == null || companion.method_31481() || companion.method_37908() != client.field_1687) {
                spawnDelayTicks++;
                if (spawnDelayTicks > 20) {
                    spawn(client);
                    spawnDelayTicks = 0;
                }
                return;
            }

            tickCounter++;
            updateSurvival(client);
            updateDamage(client);

            if (tickCounter % 5 == 0) {
                updateMovement(client);
            }
            if (tickCounter % 20 == 0) {
                updateBehavior(client);
            }
        } catch (Exception exception) {
            AiCompanionClient.addChatMessage(class_2561.method_43470("[AI Companion] 实体更新出错：" + exception.getMessage()));
        }
    }

    public static void respawn(class_310 client) {
        skinUuid = UUID.randomUUID();
        remove(client);
        spawnDelayTicks = 0;
        deathCooldownTicks = 0;
    }

    public static void remove(class_310 client) {
        if (companion == null) {
            return;
        }
        try {
            if (client.field_1687 != null && !companion.method_31481()) {
                client.field_1687.method_2945(companion.method_5628(), class_1297.class_5529.field_26999);
            }
        } catch (Exception ignored) {
        }
        companion = null;
    }

    public static boolean isCompanionActive() {
        return companion != null && !companion.method_31481();
    }

    public static void onPlayerChat(String message) {
        if (!isCompanionActive() || isThinking) {
            return;
        }

        String lowerMsg = message.toLowerCase();
        String modelName = AiCompanionConfig.modelName().toLowerCase();
        String companionName = COMPANION_NAME.toLowerCase();

        boolean shouldReply = lowerMsg.contains("@" + modelName)
                || lowerMsg.contains("@*" + modelName)
                || lowerMsg.contains(companionName)
                || lowerMsg.contains("玄玄")
                || lowerMsg.contains("ai");

        if (!shouldReply) {
            return;
        }

        long delay = 800 + RANDOM.nextInt(1500);
        isThinking = true;

        CompletableFuture.delayedExecutor(delay, java.util.concurrent.TimeUnit.MILLISECONDS)
                .execute(() -> {
                    try {
                        String response = AiRouter.reply(message);
                        class_310 client = class_310.method_1551();
                        client.execute(() -> {
                            AiCompanionClient.addChatMessage(
                                    class_2561.method_43470("[" + COMPANION_NAME + "] " + response)
                            );
                            isThinking = false;
                        });
                    } catch (Exception exception) {
                        isThinking = false;
                    }
                });
    }

    private static void spawn(class_310 client) {
        try {
            if (client.field_1687 == null || client.field_1724 == null) return;

            GameProfile profile = new GameProfile(skinUuid, COMPANION_NAME);
            companion = new class_745(client.field_1687, profile);
            class_243 spawnPos = companionPosition(client, 2.0D);
            companion.method_5808(spawnPos.field_1352, spawnPos.field_1351, spawnPos.field_1350, client.field_1724.method_36454(), 0.0F);
            client.field_1687.method_53875(companion);
            companion.method_6033(20.0f);
        } catch (Exception exception) {
            AiCompanionClient.addChatMessage(class_2561.method_43470("[AI Companion] 生成实体失败：" + exception.getMessage()));
            companion = null;
        }
    }

    private static void updateSurvival(class_310 client) {
        if (companion == null || client.field_1724 == null) return;
        try {
            companion.method_5855(companion.method_5748());
        } catch (Exception ignored) {
        }
    }

    private static void updateDamage(class_310 client) {
        if (companion == null || companion.method_6032() <= 0) return;
        try {
            if (companion.field_6017 > 3.0f) {
                float damage = (companion.field_6017 - 3.0f) * 0.5f;
                companion.method_6033(Math.max(0, companion.method_6032() - damage));
                companion.field_6017 = 0.0f;
            }

            if (companion.method_6032() <= 0) {
                onDeath(client);
            }
        } catch (Exception ignored) {
        }
    }

    private static void onDeath(class_310 client) {
        AiCompanionClient.addChatMessage(class_2561.method_43470("[" + COMPANION_NAME + "] 已死亡，3秒后重生..."));
        remove(client);
        deathCooldownTicks = 60;
    }

    private static void updateMovement(class_310 client) {
        if (companion == null || client.field_1724 == null) {
            return;
        }
        try {
            double squaredDistance = companion.method_5858(client.field_1724);

            if (squaredDistance > 400.0D) {
                class_243 position = companionPosition(client, 2.0D);
                companion.method_5808(position.field_1352, position.field_1351, position.field_1350, client.field_1724.method_36454(), 0.0F);
                companion.method_18800(0, 0, 0);
                return;
            }

            if (squaredDistance > 9.0D) {
                class_243 target = companionPosition(client, 2.5D);
                class_243 diff = target.method_1020(companion.method_19538());
                class_243 movement = diff.method_1021(0.12D);

                if (companion.method_24828() && shouldJump(client, diff)) {
                    movement = new class_243(movement.field_1352, 0.42D, movement.field_1350);
                } else {
                    movement = new class_243(movement.field_1352, companion.method_18798().field_1351, movement.field_1350);
                }

                companion.method_18799(movement);

                float yaw = (float) Math.toDegrees(Math.atan2(-diff.field_1352, diff.field_1350));
                companion.method_36456(yaw);
                companion.method_5847(yaw);
            } else {
                class_243 vel = companion.method_18798();
                companion.method_18800(vel.field_1352 * 0.5, vel.field_1351, vel.field_1350 * 0.5);

                if (RANDOM.nextInt(15) == 0) {
                    facePlayer(client);
                }
            }
        } catch (Exception ignored) {
        }
    }

    private static boolean shouldJump(class_310 client, class_243 diff) {
        return diff.field_1351 > 0.5;
    }

    private static void updateBehavior(class_310 client) {
        if (companion == null || client.field_1724 == null) return;
        try {
            if (RANDOM.nextInt(8) == 0) {
                facePlayer(client);
            }
        } catch (Exception ignored) {
        }
    }

    private static void facePlayer(class_310 client) {
        if (companion == null || client.field_1724 == null) return;
        try {
            double dx = client.field_1724.method_23317() - companion.method_23317();
            double dz = client.field_1724.method_23321() - companion.method_23321();
            float yaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
            companion.method_36456(yaw);
            companion.method_5847(yaw);
        } catch (Exception ignored) {
        }
    }

    private static class_243 companionPosition(class_310 client, double distance) {
        float yawRadians = client.field_1724.method_36454() * class_3532.field_29847;
        double offsetX = -class_3532.method_15374(yawRadians) * distance;
        double offsetZ = class_3532.method_15362(yawRadians) * distance;
        return client.field_1724.method_19538().method_1031(offsetX, 0.0D, offsetZ);
    }
}
